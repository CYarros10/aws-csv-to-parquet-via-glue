from __future__ import print_function
import boto3
import base64
import datetime,dateutil
import json
import os
import logging
from requests_aws4auth import AWS4Auth
from crhelper import CfnResource

# Initialize CFN Resource Helper
helper = CfnResource()

# Initialize Logger
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# environment variables
s3_bucket_name = str(os.environ['S3_BUCKET'])
lambda_arn = str(os.environ['LAMBDA_ARN'])

# S3 Client
s3 = boto3.resource('s3')

@helper.create
def add_s3_trigger(event, context):
    bucket_notification = s3.BucketNotification(s3_bucket_name)
    print(bucket_notification)
    response = bucket_notification.put(
        NotificationConfiguration={'LambdaFunctionConfigurations': [
            {
                'LambdaFunctionArn': lambda_arn,
                'Events': [
                    's3:ObjectCreated:*'
                ]

            }
        ]})
    print("Add bucket notification complete...")

@helper.update
def no_op(_, __):
    pass

@helper.delete
def delete_notification(event, context):
    bucket_notification = s3.BucketNotification(s3_bucket_name)
    response = bucket_notification.put(
      NotificationConfiguration={}
    )
    print("Delete bucket notification completed....")

def lambda_handler(event, context):
    return helper(event, context)
